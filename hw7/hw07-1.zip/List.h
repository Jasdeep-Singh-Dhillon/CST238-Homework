#ifndef LIST_H
#define LIST_H

#include <iostream>
using namespace std;
class List 
{
  public:
  List();    // Constructor. Default 50
  List(int capacityValue);
  ~List();              // Destructor
  List(const List& org); // Copy constructor
  List& operator =(const List& rightSide);  // Assignment operator
  bool empty() const; 
  void insert(int item, int pos);
  void erase(int pos);  
  void display() const;
  void setCapacity (int newCapacity);
  int getCapacity() const { return myCapacity; };
  int getSize() const { return mySize; };
  void append(int item);
  bool removeLast();
  void resize(int newCapacity);
  private:
  int mySize;     // current size of list
  int myCapacity; // capacity of array
  int * myArray;  // pointer to dynamic array
}; 
#endif