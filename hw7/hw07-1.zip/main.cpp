#include <iostream>
#include <climits>
#include "List.h"
using namespace std;

//--- Client program to test the List class which uses the dynamic memory.
int main() 
{
  List intList (5);
  
  for(int i=0; i<13; i++)
  {
    intList.append(i+1);
  }

  intList.display();
  cout << intList.getCapacity() << " " << intList.getSize() << endl;

}